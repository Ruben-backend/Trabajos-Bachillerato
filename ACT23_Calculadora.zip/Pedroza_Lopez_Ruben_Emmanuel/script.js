const pantalla = document.getElementById("pantalla");
const botones = document.querySelectorAll("button");

botones.forEach(boton => {
    boton.addEventListener("click", () => {
        const valor = boton.textContent;

        if (valor === "C") {
            pantalla.value = "";
        }

        else if (valor === "⌫") {
            pantalla.value = pantalla.value.slice(0, -1);
        }

        else if (valor === "=") {
            calcular();
        }

        else if (valor === "√") {
            pantalla.value += "√";
        }

        else {
            pantalla.value += valor;
        }
    });
});

// Función para procesar el resultado
function calcular() {
    let operacion = pantalla.value;

    // Reemplazos simples
    operacion = operacion.replace(/x/g, "*");
    operacion = operacion.replace(/÷/g, "/");
    operacion = operacion.replace(/%/g, "/100");
    operacion = operacion.replace(/√(\d+)/g, "Math.sqrt($1)"); //La verdad esto lo busuqe en internet

    try {
        pantalla.value = eval(operacion);
    } catch {
        pantalla.value = "Error";
    }
}
