// Cargar el JSON solo una vez
let personas = [];

fetch("datos.json")
    .then(res => res.json())
    .then(data => {
        personas = data;
    })



// Funcion para mostrar resultados
function mostrar(lista) {
    const div = document.getElementById("resultado");
    div.innerHTML = ""; // Limpiar

    if (lista.length === 0) {
        div.innerHTML = "<p>No hay datos para mostrar.</p>";
        return;
    }

    let html = "<table border='1'><tr><th>Nombre</th><th>Edad</th><th>Promedio</th><th>Género</th></tr>";

    lista.forEach(p => {
        html += `
            <tr>
                <td>${p.nombre}</td>
                <td>${p.edad}</td>
                <td>${p.promedio}</td>
                <td>${p.genero}</td>
            </tr>
        `;
    });

    html += "</table>";
    div.innerHTML = html;
}

//Comportamientos de los botones

// Todos
document.getElementById("btn-todos").onclick = () => {
    mostrar(personas);
};

// Mayores de edad
document.getElementById("btn-mayores").onclick = () => {
    const mayores = personas.filter(p => p.edad >= 18);
    mostrar(mayores);
};

// Menores de edad
document.getElementById("btn-menores").onclick = () => {
    const menores = personas.filter(p => p.edad < 18);
    mostrar(menores);
};

// Aprobados
document.getElementById("btn-aprobados").onclick = () => {
    const aprobados = personas.filter(p => p.promedio >= 6);
    mostrar(aprobados);
};

// Reprobados
document.getElementById("btn-reprobados").onclick = () => {
    const reprobados = personas.filter(p => p.promedio < 6);
    mostrar(reprobados);
};

// Hombres
document.getElementById("btn-hombres").onclick = () => {
    const hombres = personas.filter(p => p.genero === "H");
    mostrar(hombres);
};

// Mujeres
document.getElementById("btn-mujeres").onclick = () => {
    const mujeres = personas.filter(p => p.genero === "M");
    mostrar(mujeres);
};

// Limpiar pantalla
document.getElementById("btn-limpiar").onclick = () => {
    document.getElementById("resultado").innerHTML = "<p> ´Listo, limpio papito´ </p>";
};
